package com.kevin.ndk12_mk;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    static {
        System.loadLibrary("getndk"); // 如果是动态库：必须先加载，让系统内存生成一个副部，此副部给总库用
        System.loadLibrary("MyLoginJar"); // 加载总库
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getMyLibMethod();;
    }

    public native void getMyLibMethod();
}
