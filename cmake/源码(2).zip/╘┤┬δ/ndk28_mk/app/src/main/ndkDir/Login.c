#include <jni.h>
#include <android/log.h>

extern int get(); // 声明一个函数

JNIEXPORT void JNICALL Java_com_kevin_ndk12_1mk_MainActivity_getMyLibMethod
        (JNIEnv * env, jobject inst) {
    __android_log_print(ANDROID_LOG_DEBUG, "Derry", "测试库里面的方法，返回值：%d", get());
}

