package com.derry.ndk28_cmake;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.derry.ndk28_cmake.databinding.ActivityMainBinding;

import org.fmod.FMOD;

public class MainActivity extends AppCompatActivity {

    static {
       /* System.loadLibrary("fmod");
        System.loadLibrary("fmodL");*/
        // System.loadLibrary("getndk"); // gcc 旧版本交叉编译生成的动态库

        // 为什么不需要写 load(libcount) 默认使用AS Clang 编译方式，会自动预加载

        // 总库：都是动态库，加载库无法加载
        System.loadLibrary("native-lib"); // 总库 静态库时 不能写这句话，
    }

    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        TextView tv = binding.sampleText;
        tv.setText(stringFromJNI());

        FMOD.init(this);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        FMOD.close();
    }

    public native String stringFromJNI();
}