#ifndef NDK28_CMAKE_COUNTUTIL_H
#define NDK28_CMAKE_GETUTIL_H

#include <stdio.h>

const char * get1_action();
const char * get2_action();
const char * get3_action();

#endif //NDK28_CMAKE_COUNTUTIL_H
