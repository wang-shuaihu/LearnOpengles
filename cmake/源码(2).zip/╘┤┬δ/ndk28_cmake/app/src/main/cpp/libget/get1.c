#include "getutil.h"

const char * get1_action() {
    return "九阳神功";
}



