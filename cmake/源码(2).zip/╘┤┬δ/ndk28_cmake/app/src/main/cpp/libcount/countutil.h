#ifndef NDK28_CMAKE_COUNTUTIL_H
#define NDK28_CMAKE_COUNTUTIL_H

#include <stdio.h>

int add_action(int number1, int number2);  // 加法运算函数的声明
int sub_action(int number1, int number2);  // 减法运算函数的声明
int mul_action(int number1, int number2);  // 乘法运算函数的声明
int div_action(int number1, int number2);  // 除法运算函数的声明

#endif //NDK28_CMAKE_COUNTUTIL_H
