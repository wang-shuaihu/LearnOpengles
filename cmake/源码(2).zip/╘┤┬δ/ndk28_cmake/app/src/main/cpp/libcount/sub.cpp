#include "countutil.h"

int sub_action(int number1, int number2) {
    return number1 - number2;
}



