#include "getutil.h"

const char * get3_action() {
    return "降龙十八掌";
}



