#include "getutil.h"

const char * get2_action() {
    return "三分归元气";
}



