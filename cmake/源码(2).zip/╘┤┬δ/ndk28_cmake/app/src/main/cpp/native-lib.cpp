#include <jni.h>
#include <string>

// 日志输出
#include <android/log.h>

#define TAG "Derry"
// __VA_ARGS__ 代表 ...的可变参数
#define LOGD(...) __android_log_print(ANDROID_LOG_DEBUG, TAG,  __VA_ARGS__);
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, TAG,  __VA_ARGS__);
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG,  __VA_ARGS__);

extern "C" {
    #include "libget/getutil.h"
}

// 不用加 extern "C"  因为本来就是cpp
#include "libcount/countutil.h" // 1  2

extern "C" JNIEXPORT jstring JNICALL
Java_com_derry_ndk28_1cmake_MainActivity_stringFromJNI(
        JNIEnv* env,
        jobject /* this */) {
    std::string hello = "Cmake";

    // get信息的输出显示
    LOGD("get1_action:%s", get1_action());
    LOGD("get2_action:%s", get2_action());
    LOGD("get3_action:%s", get3_action());

    // count信息的输出显示
    LOGD("add_action:%d", add_action(1, 1));
    LOGD("sub_action:%d", sub_action(10, 9));
    LOGD("mul_action:%d", mul_action(8, 8));
    LOGD("div_action:%d", div_action(100, 2));

    return env->NewStringUTF(hello.c_str());
}